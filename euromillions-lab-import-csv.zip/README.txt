EUROMILLIONS LAB — version import CSV
1. Déposer index.html à la racine du dépôt GitHub Pages.
2. Déposer .nojekyll à la racine.
3. GitHub Pages doit publier la branche/répertoire contenant index.html.
4. Ouvrir le site et utiliser « Choisir un fichier CSV ».
Le traitement est local au navigateur : le fichier n'est pas envoyé à un serveur.
